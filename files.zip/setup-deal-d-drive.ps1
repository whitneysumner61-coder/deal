# ============================================
# Setup DealFlow AI on D:\deal and push to GitHub
# ============================================

Write-Host "Setting up DealFlow AI on D:\deal..." -ForegroundColor Green

# Step 1: Download and extract the archive
$archivePath = "$env:USERPROFILE\Downloads\dealflow-ai-ready-to-push.tar.gz"

if (Test-Path $archivePath) {
    Write-Host "Found archive, extracting..." -ForegroundColor Yellow
    
    # Extract using tar (Windows 10+ has built-in tar)
    Set-Location $env:USERPROFILE\Downloads
    tar -xzf dealflow-ai-ready-to-push.tar.gz
    
    # Copy to D:\deal
    Write-Host "Copying to D:\deal..." -ForegroundColor Yellow
    Copy-Item -Path ".\dealflow-ai\*" -Destination "D:\deal\" -Recurse -Force
    
    # Clean up
    Remove-Item -Path ".\dealflow-ai" -Recurse -Force
} else {
    Write-Host "Archive not found. Please download dealflow-ai-ready-to-push.tar.gz to your Downloads folder first." -ForegroundColor Red
    exit 1
}

# Step 2: Initialize Git and push
Write-Host "Initializing Git repository..." -ForegroundColor Yellow
Set-Location D:\deal

# Configure git user if not already set
$gitUser = git config user.name
if (-not $gitUser) {
    git config user.name "Whitney Sumner"
    git config user.email "whitneysumner61@example.com"
}

# Initialize and push
git init
git add -A
git commit -m "Initial commit: DealFlow AI Underwriting Engine"
git branch -M main
git remote add origin https://github.com/whitneysumner61-coder/deal.git

Write-Host "Pushing to GitHub..." -ForegroundColor Yellow
git push -u origin main --force

Write-Host "✓ Complete! Repository is now at D:\deal and pushed to GitHub" -ForegroundColor Green
Write-Host "Repository URL: https://github.com/whitneysumner61-coder/deal" -ForegroundColor Cyan
